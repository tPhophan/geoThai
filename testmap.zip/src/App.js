import React, { useState } from "react";
import { useMapEvents } from "react-leaflet/hooks";
import { MapContainer, TileLayer, Marker, Popup, GeoJSON } from "react-leaflet";
import thai from "./thai.json";

export default function App() {
  const [info, setInfo] = useState({
    select: null,
    data: {},
    visible: false,
  });

  const formatNumber = (value) => {
    return parseFloat(value).toLocaleString("th-TH", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
  };

  function getColor(d) {
    return d > 3000
      ? "#800026"
      : d > 2500
      ? "#BD0026"
      : d > 2000
      ? "#E31A1C"
      : d > 1500
      ? "#FC4E2A"
      : d > 1000
      ? "#FD8D3C"
      : d > 500
      ? "#FEB24C"
      : d > 250
      ? "#FED976"
      : "#FFEDA0";
  }

  function style(feature) {
    return {
      fillColor: getColor(feature.properties.total),
      weight: 2,
      opacity: 1,
      color: "white",
      dashArray: "3",
      fillOpacity: 0.7,
    };
  }

  const containerStyle = {
    width: "100%",
    height: "100vh",
  };

  return (
    <>
      <div
        style={{
          position: "absolute",
          display: info?.visible ? "flex" : "none",
          zIndex: "1040",
          background: "white",
          height: "100vh",
          padding: "10px",
          width: "25%",
        }}
      >
        {`ชื่อภาษาอังกฤษ : ${info?.data?.name ?? " - "} `}
        <br></br>
        {`ชื่อภาษาไทย : ${info?.data?.nameTh ?? " - "} `}
        <br></br>
        {`ชาย : ${formatNumber(info?.data?.man * 1000)} คน `}
        <br></br>
        {`หญิง : ${formatNumber(info?.data?.woman * 1000)} คน `}
        <br></br>
        {`ทั้งหมด : ${formatNumber(info?.data?.total * 1000)} คน `}
        <br></br>
      </div>
      <MapContainer
        className="map"
        center={[13, 101.5]}
        zoom={5}
        style={containerStyle}
        attributionControl={true}
        doubleClickZoom={false}
      >
        <TileLayer
          attribution='&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* {data?.map((item, index) => (
          <Marker key={index} position={[item.lat, item.lng]}>
            <Popup>{`No.:${index} Lat:${item.lat} Lng:${item.lng}`}</Popup>
          </Marker>
        ))} */}

        {thai ? (
          <GeoJSON
            data={thai}
            style={style}
            eventHandlers={{
              click: (e) => {
                const data = e.layer.feature.properties;
                if (info?.select == data.name) {
                  setInfo({
                    select: null,
                    data: data,
                    visible: false,
                  });
                } else {
                  setInfo({
                    select: data.name,
                    data: data,
                    visible: true,
                  });
                }
              },
              mouseover: (e) => {
                e.layer.setStyle({
                  weight: 5,
                  color: "#666",
                  dashArray: "",
                  fillOpacity: 0.7,
                });
              },
              mouseout: (e) => {
                e.layer.setStyle({
                  weight: 2,
                  opacity: 1,
                  color: "white",
                  dashArray: "3",
                  fillOpacity: 0.7,
                });
              },
            }}
          />
        ) : null}
        {/* <LocationMarker /> */}
      </MapContainer>
    </>
  );
}
